"use client"

import { ScrollArea } from "@/components/ui/scroll-area"
import { Button } from "@/components/ui/button"
import { X, Search } from "lucide-react"
import { Input } from "@/components/ui/input"
import { useState } from "react"

export function UserList({ users, onSelectUser, onClose }) {
  const [searchQuery, setSearchQuery] = useState("")

  const filteredUsers = users.filter(
    (user) =>
      user.display_name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (user.phone_number && user.phone_number.includes(searchQuery)),
  )

  return (
    <div className="flex-1 flex flex-col">
      <div className="h-[60px] border-b border-border flex items-center justify-between px-5 bg-card">
        <h2 className="font-semibold text-lg">Cuộc trò chuyện mới</h2>
        <Button variant="ghost" size="icon" onClick={onClose} className="rounded-full">
          <X className="h-5 w-5" />
        </Button>
      </div>
      <div className="px-4 py-3">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Tìm kiếm theo tên hoặc số điện thoại"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10 bg-secondary border-0 rounded-full"
          />
        </div>
      </div>
      <ScrollArea className="flex-1">
        <div className="py-1">
          {filteredUsers.length === 0 ? (
            <div className="text-center py-12 text-muted-foreground text-sm">Không tìm thấy người dùng</div>
          ) : (
            filteredUsers.map((user) => {
              const isOnline = user.status === "online"
              return (
                <button
                  key={user.id}
                  onClick={() => onSelectUser(user.id)}
                  className="w-full px-4 py-3 flex items-center gap-3 hover:bg-accent/50 transition-colors text-left"
                >
                  <div className="relative flex-shrink-0">
                    <div className="h-12 w-12 rounded-full bg-gradient-to-br from-blue-500 to-purple-500 flex items-center justify-center text-white font-semibold text-lg">
                      {user.display_name.charAt(0).toUpperCase()}
                    </div>
                    {isOnline && (
                      <div className="absolute bottom-0 right-0 h-3.5 w-3.5 bg-green-500 rounded-full border-2 border-card" />
                    )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-medium truncate">{user.display_name}</p>
                    <p className="text-sm text-muted-foreground">{user.phone_number || "Không có số điện thoại"}</p>
                  </div>
                </button>
              )
            })
          )}
        </div>
      </ScrollArea>
    </div>
  )
}
