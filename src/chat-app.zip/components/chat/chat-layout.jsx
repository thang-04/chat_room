"use client"

import { useState, useEffect } from "react"
import { ConversationList } from "./conversation-list"
import { MessageArea } from "./message-area"
import { UserList } from "./user-list"
import { Button } from "@/components/ui/button"
import { MessageSquarePlus, Menu, Search } from "lucide-react"
import { Input } from "@/components/ui/input"

export default function ChatLayout({ currentUser, conversations: initialConversations, allUsers }) {
  const [selectedConversationId, setSelectedConversationId] = useState(null)
  const [showUserList, setShowUserList] = useState(false)
  const [conversations, setConversations] = useState(initialConversations)
  const [searchQuery, setSearchQuery] = useState("")

  useEffect(() => {
    const loadConversations = () => {
      const stored = localStorage.getItem("conversations")
      if (stored) {
        const allConversations = JSON.parse(stored)
        // Filter conversations where current user is a participant
        const userConversations = allConversations.filter((conv) =>
          conv.participants.some((p) => p.user_id === currentUser.id),
        )
        setConversations(userConversations)
      }
    }

    loadConversations()

    // Refresh conversations every second to show new messages
    const interval = setInterval(loadConversations, 1000)
    return () => clearInterval(interval)
  }, [currentUser.id])

  const handleLogout = () => {
    localStorage.removeItem("currentUser")
    window.location.href = "/"
  }

  const handleNewConversation = () => {
    setShowUserList(true)
  }

  const handleSelectUser = (userId) => {
    const existingConversation = conversations.find((conv) =>
      conv.participants.some((p) => p.user_id === userId && conv.participants.length === 2),
    )

    if (existingConversation) {
      setSelectedConversationId(existingConversation.id)
      setShowUserList(false)
      return
    }

    const selectedUser = allUsers.find((u) => u.id === userId)
    if (!selectedUser) return

    const newConversation = {
      id: `conv-${currentUser.id}-${userId}`,
      updated_at: new Date().toISOString(),
      last_message: "",
      participants: [
        {
          user_id: currentUser.id,
          profiles: {
            id: currentUser.id,
            display_name: currentUser.display_name,
            phone_number: currentUser.phone_number,
            status: "online",
          },
        },
        {
          user_id: selectedUser.id,
          profiles: selectedUser,
        },
      ],
    }

    // Save to localStorage
    const allConversations = JSON.parse(localStorage.getItem("conversations") || "[]")
    allConversations.push(newConversation)
    localStorage.setItem("conversations", JSON.stringify(allConversations))

    setConversations([newConversation, ...conversations])
    setSelectedConversationId(newConversation.id)
    setShowUserList(false)
  }

  const selectedConversation = conversations.find((c) => c.id === selectedConversationId)
  const otherParticipant = selectedConversation?.participants.find((p) => p.user_id !== currentUser.id)

  return (
    <div className="flex h-screen bg-background">
      <div className="w-[420px] border-r border-border flex flex-col bg-card">
        <div className="h-[60px] border-b border-border flex items-center justify-between px-5 bg-card">
          <Button variant="ghost" size="icon" className="rounded-full">
            <Menu className="h-5 w-5" />
          </Button>
          <h1 className="text-lg font-semibold">Telegram</h1>
          <div className="flex items-center gap-2">
            <Button variant="ghost" size="icon" className="rounded-full" onClick={handleNewConversation}>
              <MessageSquarePlus className="h-5 w-5" />
            </Button>
            <Button variant="ghost" size="sm" onClick={handleLogout} className="text-xs">
              Đăng xuất
            </Button>
          </div>
        </div>

        <div className="px-4 py-3">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Tìm kiếm"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 bg-secondary border-0 rounded-full"
            />
          </div>
        </div>

        {showUserList ? (
          <UserList users={allUsers} onSelectUser={handleSelectUser} onClose={() => setShowUserList(false)} />
        ) : (
          <ConversationList
            conversations={conversations}
            currentUserId={currentUser.id}
            selectedConversationId={selectedConversationId}
            onSelectConversation={setSelectedConversationId}
            searchQuery={searchQuery}
          />
        )}
      </div>

      <div className="flex-1 flex flex-col bg-background">
        {selectedConversationId && otherParticipant ? (
          <>
            <div className="h-[60px] border-b border-border flex items-center px-5 bg-card">
              <div className="flex items-center gap-3 flex-1">
                <div className="relative">
                  <div className="h-10 w-10 rounded-full bg-gradient-to-br from-blue-500 to-purple-500 flex items-center justify-center text-white font-semibold">
                    {otherParticipant.profiles.display_name.charAt(0).toUpperCase()}
                  </div>
                  {otherParticipant.profiles.status === "online" && (
                    <div className="absolute bottom-0 right-0 h-3 w-3 bg-green-500 rounded-full border-2 border-card" />
                  )}
                </div>
                <div>
                  <p className="font-semibold">{otherParticipant.profiles.display_name}</p>
                  <p className="text-xs text-muted-foreground">
                    {otherParticipant.profiles.phone_number || "Không có số điện thoại"}
                  </p>
                </div>
              </div>
            </div>
            <MessageArea
              conversationId={selectedConversationId}
              currentUserId={currentUser.id}
              otherUserId={otherParticipant.user_id}
              otherUserName={otherParticipant.profiles.display_name}
            />
          </>
        ) : (
          <div className="flex-1 flex items-center justify-center text-muted-foreground">
            <div className="text-center">
              <div className="h-32 w-32 mx-auto mb-6 rounded-full bg-primary/10 flex items-center justify-center">
                <MessageSquarePlus className="h-16 w-16 text-primary/50" />
              </div>
              <h2 className="text-2xl font-semibold mb-2 text-foreground">Chọn một cuộc trò chuyện</h2>
              <p className="text-sm">Chọn từ danh sách bên trái hoặc bắt đầu cuộc trò chuyện mới</p>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
