"use client"

import { useEffect, useState, useRef } from "react"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Send, Smile } from "lucide-react"
import { cn } from "@/lib/utils"

const getStoredMessages = () => {
  if (typeof window === "undefined") return {}
  const stored = localStorage.getItem("chatMessages")
  return stored ? JSON.parse(stored) : {}
}

const saveMessage = (conversationId, message) => {
  const allMessages = getStoredMessages()
  if (!allMessages[conversationId]) {
    allMessages[conversationId] = []
  }
  allMessages[conversationId].push(message)
  localStorage.setItem("chatMessages", JSON.stringify(allMessages))
}

const getConversationMessages = (conversationId) => {
  const allMessages = getStoredMessages()
  return allMessages[conversationId] || []
}

export function MessageArea({ conversationId, currentUserId, otherUserId, otherUserName }) {
  const [messages, setMessages] = useState([])
  const [newMessage, setNewMessage] = useState("")
  const [isLoading, setIsLoading] = useState(true)
  const scrollRef = useRef(null)

  useEffect(() => {
    setIsLoading(true)
    setTimeout(() => {
      const storedMessages = getConversationMessages(conversationId)
      setMessages(storedMessages)
      setIsLoading(false)
    }, 300)
  }, [conversationId])

  useEffect(() => {
    scrollToBottom()
  }, [messages])

  const scrollToBottom = () => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight
    }
  }

  const handleSendMessage = (e) => {
    e.preventDefault()
    if (!newMessage.trim()) return

    const messageContent = newMessage.trim()
    const newMsg = {
      id: `msg-${Date.now()}`,
      content: messageContent,
      sender_id: currentUserId,
      receiver_id: otherUserId,
      sender_name: "Bạn",
      created_at: new Date().toISOString(),
    }

    saveMessage(conversationId, newMsg)
    setMessages([...messages, newMsg])
    setNewMessage("")

    // Update conversation timestamp
    const conversations = JSON.parse(localStorage.getItem("conversations") || "[]")
    const convIndex = conversations.findIndex((c) => c.id === conversationId)
    if (convIndex !== -1) {
      conversations[convIndex].updated_at = new Date().toISOString()
      conversations[convIndex].last_message = messageContent
      localStorage.setItem("conversations", JSON.stringify(conversations))
    }
  }

  return (
    <div className="flex-1 flex flex-col">
      <div className="flex-1 relative overflow-hidden">
        <div
          className="absolute inset-0 opacity-[0.02]"
          style={{
            backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fillRule='evenodd'%3E%3Cg fill='%23ffffff' fillOpacity='1'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`,
          }}
        />

        <ScrollArea className="h-full p-4" ref={scrollRef}>
          {isLoading ? (
            <div className="flex items-center justify-center h-full text-muted-foreground">Đang tải...</div>
          ) : messages.length === 0 ? (
            <div className="flex items-center justify-center h-full text-muted-foreground">
              <div className="text-center">
                <div className="h-20 w-20 mx-auto mb-4 rounded-full bg-primary/10 flex items-center justify-center">
                  <Send className="h-10 w-10 text-primary/50" />
                </div>
                <p>Chưa có tin nhắn nào</p>
                <p className="text-sm mt-1">Hãy bắt đầu cuộc trò chuyện!</p>
              </div>
            </div>
          ) : (
            <div className="space-y-3">
              {messages.map((message) => {
                const isCurrentUser = message.sender_id === currentUserId
                return (
                  <div key={message.id} className={cn("flex", isCurrentUser ? "justify-end" : "justify-start")}>
                    <div className="flex items-end gap-2 max-w-[75%]">
                      {!isCurrentUser && (
                        <div className="h-8 w-8 rounded-full bg-gradient-to-br from-blue-500 to-purple-500 flex items-center justify-center text-white text-xs font-semibold flex-shrink-0">
                          {otherUserName?.charAt(0).toUpperCase() || "?"}
                        </div>
                      )}

                      <div
                        className={cn(
                          "rounded-2xl px-4 py-2 shadow-sm",
                          isCurrentUser
                            ? "bg-primary text-primary-foreground rounded-br-md"
                            : "bg-secondary text-foreground rounded-bl-md",
                        )}
                      >
                        <p className="text-[15px] leading-relaxed break-words">{message.content}</p>
                        <p
                          className={cn(
                            "text-[11px] mt-1 text-right",
                            isCurrentUser ? "text-primary-foreground/70" : "text-muted-foreground",
                          )}
                        >
                          {new Date(message.created_at).toLocaleTimeString("vi-VN", {
                            hour: "2-digit",
                            minute: "2-digit",
                          })}
                        </p>
                      </div>
                    </div>
                  </div>
                )
              })}
            </div>
          )}
        </ScrollArea>
      </div>

      <div className="border-t border-border p-4 bg-card">
        <form onSubmit={handleSendMessage} className="flex gap-2 items-end">
          <Button type="button" variant="ghost" size="icon" className="rounded-full flex-shrink-0">
            <Smile className="h-5 w-5" />
          </Button>
          <Input
            placeholder="Nhập tin nhắn..."
            value={newMessage}
            onChange={(e) => setNewMessage(e.target.value)}
            className="flex-1 bg-secondary border-0 rounded-full px-4"
          />
          <Button type="submit" size="icon" disabled={!newMessage.trim()} className="rounded-full flex-shrink-0">
            <Send className="h-5 w-5" />
          </Button>
        </form>
      </div>
    </div>
  )
}
