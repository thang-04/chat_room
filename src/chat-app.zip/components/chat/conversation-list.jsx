"use client"

import { ScrollArea } from "@/components/ui/scroll-area"
import { cn } from "@/lib/utils"

export function ConversationList({
  conversations,
  currentUserId,
  selectedConversationId,
  onSelectConversation,
  searchQuery,
}) {
  const sortedConversations = [...conversations].sort(
    (a, b) => new Date(b.updated_at).getTime() - new Date(a.updated_at).getTime(),
  )

  const filteredConversations = sortedConversations.filter((conversation) => {
    const otherParticipant = conversation.participants.find((p) => p.user_id !== currentUserId)
    const displayName = otherParticipant?.profiles?.display_name || ""
    return displayName.toLowerCase().includes(searchQuery.toLowerCase())
  })

  return (
    <ScrollArea className="flex-1">
      <div className="py-1">
        {filteredConversations.length === 0 ? (
          <div className="text-center py-12 text-muted-foreground text-sm">
            {searchQuery ? "Không tìm thấy kết quả" : "Chưa có cuộc trò chuyện nào"}
          </div>
        ) : (
          filteredConversations.map((conversation) => {
            const otherParticipant = conversation.participants.find((p) => p.user_id !== currentUserId)
            const displayName = otherParticipant?.profiles?.display_name || "Unknown User"
            const isOnline = otherParticipant?.profiles?.status === "online"

            return (
              <button
                key={conversation.id}
                onClick={() => onSelectConversation(conversation.id)}
                className={cn(
                  "w-full px-4 py-3 flex items-center gap-3 hover:bg-accent/50 transition-colors text-left",
                  selectedConversationId === conversation.id && "bg-accent",
                )}
              >
                <div className="relative flex-shrink-0">
                  <div className="h-12 w-12 rounded-full bg-gradient-to-br from-blue-500 to-purple-500 flex items-center justify-center text-white font-semibold text-lg">
                    {displayName.charAt(0).toUpperCase()}
                  </div>
                  {isOnline && (
                    <div className="absolute bottom-0 right-0 h-3.5 w-3.5 bg-green-500 rounded-full border-2 border-card" />
                  )}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-baseline justify-between mb-1">
                    <p className="font-medium truncate">{displayName}</p>
                    <p className="text-xs text-muted-foreground ml-2 flex-shrink-0">
                      {new Date(conversation.updated_at).toLocaleTimeString("vi-VN", {
                        hour: "2-digit",
                        minute: "2-digit",
                      })}
                    </p>
                  </div>
                  <p className="text-sm text-muted-foreground truncate">
                    {conversation.last_message || "Nhấn để xem tin nhắn"}
                  </p>
                </div>
              </button>
            )
          })
        )}
      </div>
    </ScrollArea>
  )
}
