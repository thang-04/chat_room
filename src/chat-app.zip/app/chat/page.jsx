"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import ChatLayout from "@/components/chat/chat-layout"

export default function ChatPage() {
  const router = useRouter()
  const [currentUser, setCurrentUser] = useState(null)

  useEffect(() => {
    const userStr = localStorage.getItem("currentUser")
    if (!userStr) {
      router.push("/")
      return
    }
    setCurrentUser(JSON.parse(userStr))
  }, [router])

  if (!currentUser) {
    return null
  }

  const mockUsers = [
    {
      id: "user-1",
      display_name: "Nguyễn Văn A",
      phone_number: "0901234567",
      status: "online",
    },
    {
      id: "user-2",
      display_name: "Trần Thị B",
      phone_number: "0912345678",
      status: "online",
    },
    {
      id: "user-3",
      display_name: "Lê Văn C",
      phone_number: "0923456789",
      status: "offline",
    },
    {
      id: "user-4",
      display_name: "Phạm Thị D",
      phone_number: "0934567890",
      status: "online",
    },
    {
      id: "user-5",
      display_name: "Hoàng Văn E",
      phone_number: "0945678901",
      status: "offline",
    },
  ]

  const mockConversations = [
    {
      id: "conv-1",
      updated_at: new Date().toISOString(),
      participants: [
        {
          user_id: currentUser.id,
          profiles: {
            id: currentUser.id,
            display_name: currentUser.display_name,
            phone_number: currentUser.phone_number,
          },
        },
        {
          user_id: "user-1",
          profiles: mockUsers[0],
        },
      ],
    },
  ]

  return <ChatLayout currentUser={currentUser} conversations={mockConversations} allUsers={mockUsers} />
}
